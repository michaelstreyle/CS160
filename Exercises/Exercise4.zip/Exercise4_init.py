'''
linked_list import statement
'''
name = "Exercise4"

from Exercise4 import Node, OrderedList

__all__ = ['Node', 'OrderedList']